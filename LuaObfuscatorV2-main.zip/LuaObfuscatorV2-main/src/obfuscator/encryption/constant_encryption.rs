fn encrypt_strings(input: &mut String) {}

pub fn encrypt(input: &mut String) {
    encrypt_strings(input);
}
